package com.example.e_wmarroquin.licores;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {
    private RecyclerView recycler;
    private RecyclerView.Adapter adapter;
    private RecyclerView.LayoutManager lManager;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);
        List items = new ArrayList();

        items.add(new Licor(R.drawable.licor1, "Don Melchor", "Primer vino ultragremium de la industria chilena.", 150000));
        items.add(new Licor(R.drawable.licor2, "Sangre de Toro", "Torres, La marca de vino más admirada de Europa", 200000));
        items.add(new Licor(R.drawable.licor3, "ZONIN1821", "Una de las familias productoras de vino más importante de Italia.", 225000));
        items.add(new Licor(R.drawable.licor4, "Riunite", "Lambrusco Emilia Italia.", 300000));
        items.add(new Licor(R.drawable.licor5, "KRUG", "Champagnes Don Pérignon.", 150000));

        recycler = (RecyclerView) findViewById(R.id.ListaLicores);
        recycler.setHasFixedSize(true);

        lManager = new LinearLayoutManager(this);
        recycler.setLayoutManager(lManager);

        adapter = new adaptadorlicores(items);
        recycler.setAdapter(adapter);
    }
}
