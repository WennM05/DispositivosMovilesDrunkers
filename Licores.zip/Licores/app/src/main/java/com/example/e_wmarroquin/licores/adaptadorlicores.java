package com.example.e_wmarroquin.licores;

import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import java.util.List;

public class adaptadorlicores extends RecyclerView.Adapter<adaptadorlicores.LicoresViewHolder> {
    private List<Licor> items;

    public static class LicoresViewHolder extends RecyclerView.ViewHolder {
        // Campos respectivos de un item
        public ImageView imagenLicor;
        public TextView nombre;
        public TextView descripcion;
        public TextView precio;

        public LicoresViewHolder(View v) {
            super(v);
            imagenLicor = (ImageView) v.findViewById(R.id.imagenLicor);
            nombre = (TextView) v.findViewById(R.id.nombre);
            descripcion = (TextView) v.findViewById(R.id.descripcion);
            precio= (TextView)v.findViewById(R.id.precio);
        }
    }

    public adaptadorlicores(List<Licor> items) {
        this.items = items;
    }

    @Override
    public int getItemCount() {
        return items.size();
    }

    @Override
    public LicoresViewHolder onCreateViewHolder(ViewGroup viewGroup, int i) {
        View v = LayoutInflater.from(viewGroup.getContext())
                .inflate(R.layout.activity_main, viewGroup, false);
        return new LicoresViewHolder(v);
    }

    @Override
    public void onBindViewHolder(LicoresViewHolder viewHolder, int i) {
        viewHolder.imagenLicor.setImageResource(items.get(i).getImagenLicor());
        viewHolder.nombre.setText(items.get(i).getNombre());
        viewHolder.descripcion.setText(items.get(i).getDescripcion());
        viewHolder.precio.setText("Precio:"+Integer.toString(items.get(i).getPrecio()));
    }
}