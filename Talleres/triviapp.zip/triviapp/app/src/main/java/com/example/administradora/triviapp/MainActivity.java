package com.example.administradora.triviapp;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
    public Button Respuesta1;
    public Button Respuesta2;
    public Button Respuesta3;
    public Button Siguiente1;
    public TextView titulo;
    public TextView PreguntaUno;
    public ImageView imagen;
    public int contadorIncorrectas=0;
    public int contadorCorrectas=0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        titulo=(TextView) findViewById(R.id.textViewtitulo);
        PreguntaUno=(TextView) findViewById(R.id.pregunta1);
        imagen=(ImageView) findViewById(R.id.imageView1);
        Respuesta1=(Button)findViewById(R.id.respuesta1);
        Respuesta1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                contadorIncorrectas++;                      }
        });

        Respuesta2=(Button)findViewById(R.id.respuesta2Correcta);
        Respuesta2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                contadorCorrectas++;                       }
        });

        Respuesta3=(Button)findViewById(R.id.respuesta3);
        Respuesta3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                contadorIncorrectas++;                  }
        });

        Siguiente1=(Button)findViewById(R.id.siguiente1);
        Siguiente1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent Siguiente1= new Intent(MainActivity.this, trivia2.class);
                Siguiente1.putExtra("incorrectas", contadorIncorrectas);
                Siguiente1.putExtra("correctas", contadorCorrectas);
                startActivity(Siguiente1);                        }
        });



    }
}
