package com.example.administradora.triviapp;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

public class trivia3 extends AppCompatActivity {
    public Button Respuesta001;
    public Button Respuesta002;
    public Button Respuesta003;
    public Button Siguiente3;
    public TextView titulo3;
    public TextView PreguntaTres;
    public ImageView imagen3;
    public int contadorIncorrectas=getIntent().getIntExtra("incorrectas",0);
    public int contadorCorrectas=getIntent().getIntExtra("correctas",0);


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_trivia3);
        titulo3=(TextView) findViewById(R.id.titulo3);
        PreguntaTres=(TextView) findViewById(R.id.pregunta3);
        imagen3=(ImageView) findViewById(R.id.imagen3);
        Respuesta001=(Button)findViewById(R.id.respuesta001);
        Respuesta001.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                contadorIncorrectas++;                    }
        });

        Respuesta002=(Button)findViewById(R.id.respuesta002);
        Respuesta002.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                contadorIncorrectas++;                       }
        });

        Respuesta003=(Button)findViewById(R.id.respuesta003Correcta);
        Respuesta003.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                contadorCorrectas++;                  }
        });

        Siguiente3=(Button)findViewById(R.id.siguiente3);
        Siguiente3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent Siguiente3= new Intent(trivia3.this, trivia4.class);
                Siguiente3.putExtra("incorrectas", contadorIncorrectas);
                Siguiente3.putExtra("correctas", contadorCorrectas);
                startActivity(Siguiente3);                        }
        });


    }
}