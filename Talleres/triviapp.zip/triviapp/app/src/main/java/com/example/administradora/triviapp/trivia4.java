package com.example.administradora.triviapp;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

public class trivia4 extends AppCompatActivity {
    public Button Respuesta0001;
    public Button Respuesta0002;
    public Button Respuesta0003;
    public Button Siguiente4;
    public TextView titulo4;
    public TextView PreguntaCuatro;
    public ImageView imagen4;
    public int contadorIncorrectas=getIntent().getIntExtra("incorrectas",0);
    public int contadorCorrectas=getIntent().getIntExtra("correctas",0);

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_trivia4);
        titulo4=(TextView) findViewById(R.id.titulo4);
        PreguntaCuatro=(TextView) findViewById(R.id.pregunta4);
        imagen4=(ImageView) findViewById(R.id.imagen4);
        Respuesta0001=(Button)findViewById(R.id.respuesta0001Correcta);
        Respuesta0001.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                contadorCorrectas++;                       }
        });

        Respuesta0002=(Button)findViewById(R.id.respuesta0002);
        Respuesta0002.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                contadorIncorrectas++;                       }
        });

        Respuesta0003=(Button)findViewById(R.id.respuesta0003);
        Respuesta0003.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                contadorIncorrectas++;                 }
        });

        Siguiente4=(Button)findViewById(R.id.siguiente4);
        Siguiente4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent Siguiente4= new Intent(trivia4.this, trivia5.class);
                Siguiente4.putExtra("incorrectas", contadorIncorrectas);
                Siguiente4.putExtra("correctas", contadorCorrectas);
                startActivity(Siguiente4);                        }
        });


    }
}