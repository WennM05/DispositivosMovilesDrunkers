package com.example.administradora.triviapp;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

public class trivia2 extends AppCompatActivity{
    public Button Respuesta01;
    public Button Respuesta02;
    public Button Respuesta03;
    public Button Siguiente2;
    public TextView titulo1;
    public TextView PreguntaDos;
    public ImageView imagen2;
    public int contadorIncorrectas=getIntent().getIntExtra("incorrectas",0);
    public int contadorCorrectas=getIntent().getIntExtra("correctas",0);


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_trivia2);
        Intent Siguiente1 = getIntent();
        getIntent().getExtras().getString("parametro");
        Bundle bundle = Siguiente1.getExtras();
        titulo1=(TextView) findViewById(R.id.titulo2);
        PreguntaDos=(TextView) findViewById(R.id.pregunta2);
        imagen2=(ImageView) findViewById(R.id.imagen1);
        Respuesta01=(Button)findViewById(R.id.respuesta01Correcta);
        Respuesta01.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                contadorCorrectas++;                     }
        });

        Respuesta02=(Button)findViewById(R.id.respuesta02);
        Respuesta02.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                contadorIncorrectas++;                       }
        });

        Respuesta03=(Button)findViewById(R.id.respuesta03);
        Respuesta03.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                contadorIncorrectas++;                  }
        });

        Siguiente2=(Button)findViewById(R.id.siguiente2);
        Siguiente2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent Siguiente2= new Intent(trivia2.this, trivia3.class);
                Siguiente2.putExtra("incorrectas", contadorIncorrectas);
                Siguiente2.putExtra("correctas", contadorCorrectas);
                startActivity(Siguiente2);                        }
        });


    }
}