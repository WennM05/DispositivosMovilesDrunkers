package com.example.administradora.triviapp;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.TextView;

public class resultado extends AppCompatActivity {
    public TextView ContadorRespuestasCorrectas;
    public TextView ContadorRespuestasIncorrectas;
    public int contadorIncorrectas=getIntent().getIntExtra("incorrectas",0);
    public int contadorCorrectas=getIntent().getIntExtra("correctas",0);
    public TextView ResultadoTexto;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_resultado);
        ResultadoTexto=(TextView) findViewById(R.id.textView);
        if (contadorCorrectas==5){
            ResultadoTexto.setText("Excelente");
        }
        if (contadorCorrectas ==3 ||contadorCorrectas == 4){
            ResultadoTexto.setText("Buen trabajo");
        }
        if (contadorCorrectas >=0 && contadorCorrectas <= 2 ){
            ResultadoTexto.setText("Hay que mejorar");
        }
        ContadorRespuestasCorrectas=(TextView) findViewById(R.id.textView2);
        ContadorRespuestasCorrectas.setText("Correctas: "+contadorCorrectas);
        ContadorRespuestasIncorrectas=(TextView) findViewById(R.id.textView3);
        ContadorRespuestasIncorrectas.setText("Incorrectas: "+contadorIncorrectas);
    }
}
