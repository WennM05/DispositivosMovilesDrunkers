package com.example.administradora.triviapp;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

public class trivia5 extends AppCompatActivity {
    public Button Respuesta00001;
    public Button Respuesta00002;
    public Button Respuesta00003;
    public Button Siguiente5;
    public TextView titulo5;
    public TextView PreguntaCinco;
    public ImageView imagen5;
    public int contadorIncorrectas=getIntent().getIntExtra("incorrectas",0);
    public int contadorCorrectas=getIntent().getIntExtra("correctas",0);

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_trivia5);
        titulo5=(TextView) findViewById(R.id.titulo5);
        PreguntaCinco=(TextView) findViewById(R.id.pregunta5);
        imagen5=(ImageView) findViewById(R.id.imagen5);
        Respuesta00001=(Button)findViewById(R.id.respuesta00001);
        Respuesta00001.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                contadorIncorrectas++;                   }
        });

        Respuesta00002=(Button)findViewById(R.id.respuesta00002Correcta);
        Respuesta00002.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                contadorCorrectas++;                       }
        });

        Respuesta00003=(Button)findViewById(R.id.respuesta00003);
        Respuesta00003.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                contadorIncorrectas++;                 }
        });

        Siguiente5=(Button)findViewById(R.id.siguiente5);
        Siguiente5.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent Siguiente5= new Intent(trivia5.this, resultado.class);
                Siguiente5.putExtra("incorrectas", contadorIncorrectas);
                Siguiente5.putExtra("correctas", contadorCorrectas);
                startActivity(Siguiente5);                        }
        });


    }
}